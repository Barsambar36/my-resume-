from django.core.management.base import BaseCommand

from portfolio.models import (
    Certification,
    Education,
    Experience,
    PortfolioItem,
    Profile,
    Service,
    Skill,
    SocialLink,
)


class Command(BaseCommand):
    help = "Seed the database with demo resume content (matches the original Craftivo template)."

    def handle(self, *args, **options):
        profile, _ = Profile.objects.update_or_create(
            pk=1,
            defaults=dict(
                hero_greeting_name="example",
                hero_typed_items="Designer, Developer, Freelancer, Photographer",
                hero_background="profile/profile-bg-5.webp",
                display_name="Jordan Mitchell",
                role="Full Stack Developer",
                avatar="profile/profile-square-3.webp",
                rating="4.8",
                projects_count=156,
                years_experience=8,
                awards_count=42,
                bio_heading="Transforming Ideas into Digital Reality",
                bio_paragraph_1=(
                    "At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis "
                    "praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias "
                    "excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui "
                    "officia deserunt mollitia animi."
                ),
                bio_paragraph_2=(
                    "Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus "
                    "saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae."
                ),
                degree="Master of Science",
                location="Portland, OR",
                email="contact@example.com",
                phone="+1 (555) 234-5678",
                availability="Open to Work",
                footer_about_text=(
                    "Cras fermentum odio eu feugiat lide par naso tierra. Justo eget nada terra "
                    "videa magna derita valies darta donna mare fermentum iaculis eu non diam "
                    "phasellus."
                ),
                address_line="2847 Oak Street, San Francisco, CA 94102",
            ),
        )

        SocialLink.objects.all().delete()
        SocialLink.objects.bulk_create(
            [
                SocialLink(icon="bi-twitter-x", url="https://twitter.com", order=1),
                SocialLink(icon="bi-facebook", url="https://facebook.com", order=2),
                SocialLink(icon="bi-instagram", url="https://instagram.com", order=3),
                SocialLink(icon="bi-linkedin", url="https://linkedin.com", order=4),
            ]
        )

        Skill.objects.all().delete()
        Skill.objects.bulk_create(
            [
                Skill(name="React & Next.js", percent=95, order=1),
                Skill(name="Node.js & Express", percent=90, order=2),
                Skill(name="UI/UX & Figma", percent=88, order=3),
                Skill(name="MongoDB & PostgreSQL", percent=85, order=4),
                Skill(name="Docker & AWS", percent=80, order=5),
            ]
        )

        Experience.objects.all().delete()
        Experience.objects.bulk_create(
            [
                Experience(
                    title="Senior Creative Director",
                    company="Digital Innovation Labs",
                    period="2023 - Present",
                    is_current=True,
                    description=(
                        "Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi "
                        "ut aliquip ex ea commodo consequat duis aute."
                    ),
                    tags="Leadership, Strategy, Innovation",
                    order=1,
                ),
                Experience(
                    title="Product Design Lead",
                    company="TechForward Solutions",
                    period="2020 - 2023",
                    is_current=False,
                    description=(
                        "Sed ut perspiciatis unde omnis iste natus error sit voluptatem "
                        "accusantium doloremque laudantium totam rem aperiam."
                    ),
                    order=2,
                ),
                Experience(
                    title="UX Designer",
                    company="Creative Studio Inc",
                    period="2017 - 2020",
                    is_current=False,
                    description=(
                        "Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia "
                        "deserunt mollit anim id est laborum."
                    ),
                    order=3,
                ),
            ]
        )

        Education.objects.all().delete()
        Education.objects.bulk_create(
            [
                Education(
                    degree="Master of Design Innovation",
                    institution="Institute of Creative Arts",
                    year_range="2015 - 2017",
                    level="Masters",
                    description=(
                        "Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod "
                        "tempor incididunt ut labore."
                    ),
                    achievement="Summa Cum Laude",
                    order=1,
                ),
                Education(
                    degree="Bachelor of Fine Arts",
                    institution="Creative Arts University",
                    year_range="2011 - 2015",
                    level="Bachelor",
                    description=(
                        "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum "
                        "dolore eu fugiat nulla pariatur."
                    ),
                    order=2,
                ),
            ]
        )

        Certification.objects.all().delete()
        Certification.objects.bulk_create(
            [
                Certification(name="Advanced UX Research", year="2023", order=1),
                Certification(name="Design Leadership", year="2022", order=2),
                Certification(name="Digital Strategy", year="2021", order=3),
            ]
        )

        Service.objects.all().delete()
        Service.objects.bulk_create(
            [
                Service(
                    icon="bi-palette",
                    title="Brand Identity",
                    description="Curabitur non nulla sit amet nisl tempus convallis quis ac lectus vivamus magna.",
                    order=1,
                ),
                Service(
                    icon="bi-layout-text-window-reverse",
                    title="UI/UX Design",
                    description="Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui donec rutrum.",
                    featured=True,
                    order=2,
                ),
                Service(
                    icon="bi-code-slash",
                    title="Development",
                    description="Praesent sapien massa convallis a pellentesque nec egestas non nisi cras ornare arcu.",
                    order=3,
                ),
                Service(
                    icon="bi-phone",
                    title="Mobile Apps",
                    description="Vivamus suscipit tortor eget felis porttitor volutpat quisque velit nisi pretium ut lacinia.",
                    order=4,
                ),
            ]
        )

        PortfolioItem.objects.all().delete()
        PortfolioItem.objects.bulk_create(
            [
                PortfolioItem(
                    title="Visual Identity System",
                    category="Creative Design",
                    image="portfolio/portfolio-1.webp",
                    tags="Branding, Identity",
                    year="2024",
                    filter_key="filter-creative",
                    order=1,
                ),
                PortfolioItem(
                    title="Interactive Web Platform",
                    category="Digital Experience",
                    image="portfolio/portfolio-2.webp",
                    tags="Web Design, Development",
                    year="2024",
                    filter_key="filter-digital",
                    order=2,
                ),
                PortfolioItem(
                    title="Market Positioning",
                    category="Brand Strategy",
                    image="portfolio/portfolio-3.webp",
                    tags="Strategy, Consulting",
                    year="2023",
                    filter_key="filter-strategy",
                    order=3,
                ),
                PortfolioItem(
                    title="Custom Application",
                    category="Full Stack",
                    image="portfolio/portfolio-4.webp",
                    tags="React, Node.js",
                    year="2024",
                    filter_key="filter-development",
                    order=4,
                ),
                PortfolioItem(
                    title="Campaign Design",
                    category="Art Direction",
                    image="portfolio/portfolio-5.webp",
                    tags="Creative, Campaign",
                    year="2024",
                    filter_key="filter-creative",
                    order=5,
                ),
                PortfolioItem(
                    title="Mobile Experience",
                    category="Digital Product",
                    image="portfolio/portfolio-6.webp",
                    tags="Mobile, UI/UX",
                    year="2023",
                    filter_key="filter-digital",
                    order=6,
                ),
            ]
        )

        self.stdout.write(self.style.SUCCESS("Seed data created."))
