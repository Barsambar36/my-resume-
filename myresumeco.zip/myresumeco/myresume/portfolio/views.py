from django.http import HttpResponse, HttpResponseNotAllowed
from django.shortcuts import render

from .forms import ContactForm
from .models import (
    Certification,
    Education,
    Experience,
    Profile,
    Skill,
    SocialLink,
)


def home(request):
    context = {
        "profile": Profile.objects.first(),
        "social_links": SocialLink.objects.all(),
        "skills": Skill.objects.all(),
        "experiences": Experience.objects.all(),
        "educations": Education.objects.all(),
        "certifications": Certification.objects.all(),
        "contact_form": ContactForm(),
    }
    return render(request, "portfolio/home.html", context)


def contact_submit(request):
    """AJAX endpoint for the contact form's vendor JS (assets/vendor/php-email-form/validate.js).

    That script expects a plain-text 200 response body of exactly "OK" on success,
    or any other text to display as the error message - it never reloads the page.
    """
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])

    form = ContactForm(request.POST)
    if form.is_valid():
        form.save()
        return HttpResponse("OK", content_type="text/plain")

    errors = " ".join(
        f"{field}: {', '.join(messages)}" for field, messages in form.errors.items()
    )
    return HttpResponse(errors or "Please check your input and try again.", content_type="text/plain")
