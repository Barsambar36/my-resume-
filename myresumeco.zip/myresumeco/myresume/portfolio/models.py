from django.db import models


class Profile(models.Model):
    """Singleton holding the hero, about, and contact content for the site owner."""

    # Hero section
    hero_greeting_name = models.CharField(max_length=100, help_text='example (for editing go to admin page)')
    hero_typed_items = models.CharField(
        max_length=255,
        help_text="Comma-separated roles that type/cycle in the hero, e.g. Designer, Developer, Freelancer",
    )
    hero_background = models.ImageField(upload_to="profile/", blank=True, null=True)

    # Profile card (About section)
    display_name = models.CharField(max_length=100)
    role = models.CharField(max_length=150)
    avatar = models.ImageField(upload_to="profile/", blank=True, null=True)
    rating = models.DecimalField(max_digits=2, decimal_places=1, default=5.0)
    projects_count = models.PositiveIntegerField(default=0)
    years_experience = models.PositiveIntegerField(default=0)
    awards_count = models.PositiveIntegerField(default=0)
    cv_file = models.FileField(upload_to="documents/", blank=True, null=True)

    # About bio
    bio_heading = models.CharField(max_length=200)
    bio_paragraph_1 = models.TextField()
    bio_paragraph_2 = models.TextField(blank=True)
    degree = models.CharField(max_length=150)
    location = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=50)
    availability = models.CharField(max_length=100, default="Open to Work")

    # Footer / about blurb
    footer_about_text = models.TextField(blank=True)
    address_line = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return self.display_name

    def hero_typed_items_list(self):
        return [item.strip() for item in self.hero_typed_items.split(",") if item.strip()]

    class Meta:
        verbose_name = "Profile"
        verbose_name_plural = "Profile"


class SocialLink(models.Model):
    PLATFORM_CHOICES = [
        ("bi-twitter-x", "Twitter / X"),
        ("bi-facebook", "Facebook"),
        ("bi-instagram", "Instagram"),
        ("bi-linkedin", "LinkedIn"),
        ("bi-github", "GitHub"),
        ("bi-twitter", "Twitter"),
        ("bi-youtube", "YouTube"),
        ("bi-dribbble", "Dribbble"),
        ("bi-behance", "Behance"),
    ]
    icon = models.CharField(max_length=30, choices=PLATFORM_CHOICES)
    url = models.URLField()
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.get_icon_display()} ({self.url})"


class Skill(models.Model):
    name = models.CharField(max_length=100)
    percent = models.PositiveIntegerField(help_text="0-100")
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.name} ({self.percent}%)"


class Experience(models.Model):
    title = models.CharField(max_length=150)
    company = models.CharField(max_length=150)
    period = models.CharField(max_length=100, help_text='e.g. "2023 - Present"')
    is_current = models.BooleanField(default=False)
    description = models.TextField()
    tags = models.CharField(max_length=255, blank=True, help_text="Comma-separated, e.g. Leadership, Strategy")
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.title} @ {self.company}"

    def tags_list(self):
        return [tag.strip() for tag in self.tags.split(",") if tag.strip()]


class Education(models.Model):
    LEVEL_CHOICES = [
        ("Masters", "Masters"),
        ("Bachelor", "Bachelor"),
        ("Certificates", "Certificates"),
        ("PhD", "PhD"),
        ("Diploma", "Diploma"),
    ]
    degree = models.CharField(max_length=150)
    institution = models.CharField(max_length=150)
    year_range = models.CharField(max_length=50)
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES)
    description = models.TextField(blank=True)
    achievement = models.CharField(max_length=150, blank=True, help_text='e.g. "Summa Cum Laude"')
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.degree} - {self.institution}"


class Certification(models.Model):
    name = models.CharField(max_length=150)
    year = models.CharField(max_length=10)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return f"{self.name} ({self.year})"


class Service(models.Model):
    icon = models.CharField(max_length=50, help_text='Bootstrap icon class, e.g. "bi-palette"')
    title = models.CharField(max_length=150)
    description = models.TextField()
    featured = models.BooleanField(default=False)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return self.title


class PortfolioItem(models.Model):
    FILTER_CHOICES = [
        ("filter-creative", "Creative"),
        ("filter-digital", "Digital"),
        ("filter-strategy", "Strategy"),
        ("filter-development", "Development"),
    ]
    title = models.CharField(max_length=150)
    category = models.CharField(max_length=150, help_text='e.g. "Creative Design"')
    image = models.ImageField(upload_to="portfolio/")
    tags = models.CharField(max_length=255, blank=True, help_text="Comma-separated, e.g. Branding, Identity")
    year = models.CharField(max_length=10)
    filter_key = models.CharField(max_length=30, choices=FILTER_CHOICES)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return self.title

    def tags_list(self):
        return [tag.strip() for tag in self.tags.split(",") if tag.strip()]


class ContactMessage(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField()
    subject = models.CharField(max_length=200)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.subject} from {self.name}"
